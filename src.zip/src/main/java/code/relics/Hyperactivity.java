package code.relics;

import code.CharacterFile;
import code.cards.Focus;
import com.megacrit.cardcrawl.cards.AbstractCard;
import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
import com.megacrit.cardcrawl.vfx.cardManip.ShowCardAndObtainEffect;

import static code.ModFile.makeID;

public class Hyperactivity extends AbstractEasyRelic {
    public static final String ID = makeID("TodoItem");

    public Hyperactivity() {
        super(ID, RelicTier.STARTER, LandingSound.FLAT, CharacterFile.Enums.TEAL_COLOR);

        public void onEquip() {
            AbstractDungeon.player.masterDeck.addToTop(Focus);
        }
        }
    }