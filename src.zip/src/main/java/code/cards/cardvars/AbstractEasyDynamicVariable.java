package code.cards.cardvars;

import basemod.abstracts.DynamicVariable;

public abstract class AbstractEasyDynamicVariable extends DynamicVariable {
    
}