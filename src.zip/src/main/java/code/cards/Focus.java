package code.cards;

import com.megacrit.cardcrawl.actions.AbstractGameAction;
import com.megacrit.cardcrawl.actions.common.MakeTempCardInDrawPileAction;
import com.megacrit.cardcrawl.cards.AbstractCard;
import com.megacrit.cardcrawl.characters.AbstractPlayer;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.actions.common.ExhaustAction;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.powers.StrengthPower;
import com.megacrit.cardcrawl.powers.AbstractPower;
import com.megacrit.cardcrawl.actions.common.ApplyPowerAction;
import com.megacrit.cardcrawl.powers.DexterityPower;
import code.cards.HyperFocus;
import static code.ModFile.makeID;

public class Focus extends AbstractEasyCard {
    public final static String ID = makeID("Focus");
    // intellij stuff SKILL, SELF, COMMON, 7, 10, 0, 0, 0, 0

    public Focus() {
        super(ID, 1, CardType.ATTACK, CardRarity.SPECIAL, CardTarget.ENEMY);
        baseMagicNumber = magicNumber = 1;
        baseSecondMagic = secondMagic = 1;
        baseDamage = 0;
        baseBlock = 0;
        this.cardsToPreview = new HyperFocus();
        exhaust = true;

    }

    public void use(AbstractPlayer p, AbstractMonster m) {
        if (this.upgraded) {
            addToBot((AbstractGameAction)new ExhaustAction(1, false));
            addToBot((AbstractGameAction)new ApplyPowerAction((AbstractCreature)p, (AbstractCreature)p, (AbstractPower)new StrengthPower((AbstractCreature)p, this.magicNumber)));
            addToBot((AbstractGameAction)new ApplyPowerAction((AbstractCreature)p, (AbstractCreature)p, (AbstractPower)new DexterityPower((AbstractCreature)p, this.secondMagic)));
            AbstractCard cardToAdd = new HyperFocus();
            cardToAdd.upgrade(); // Upgrade the card
            addToBot(new MakeTempCardInDrawPileAction(cardToAdd, 1, true, true));

        } else {
            addToBot((AbstractGameAction)new ExhaustAction(1, true, false, false));
            addToBot((AbstractGameAction)new ApplyPowerAction((AbstractCreature)p, (AbstractCreature)p, (AbstractPower)new StrengthPower((AbstractCreature)p, this.magicNumber)));
            addToBot((AbstractGameAction)new ApplyPowerAction((AbstractCreature)p, (AbstractCreature)p, (AbstractPower)new DexterityPower((AbstractCreature)p, this.secondMagic)));
            AbstractCard cardToAdd = new HyperFocus();
            addToBot(new MakeTempCardInDrawPileAction(cardToAdd, 1, true, true));
                }
    }

    public void upp() {
        upgradeDamage(0);
        upgradeBlock(0);
        upgradeMagicNumber(1);
        upgradeSecondMagic(0);
        upgradeBaseCost(0);
        this.cardsToPreview.upgrade();
    }
}