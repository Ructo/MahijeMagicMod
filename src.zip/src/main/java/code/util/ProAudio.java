package code.util;

public enum ProAudio {
    /*
    Add any audio you add to your files here!
    For example, if you add "todomodResources/audio/boing.ogg", you'd add it here as BOING
    Then, you can use playAudio(ProAudio.BOING) from Wiz to play it.
    */

}